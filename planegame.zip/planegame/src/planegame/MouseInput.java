/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planegame;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

/**
 *
 * @author RC
 */
public class MouseInput extends MouseAdapter{
    private Handler handler;
    
    public MouseInput(Handler handler){
        this.handler=handler;
    }
    
    public void mousePressed(MouseEvent e){//creates a bullet based on the mouse location when clicked
        int mx=(int)e.getX();
        int my=(int)e.getY();
        int dx = mx- 490;
        int dy = my - 473;
        double d = Math.sqrt((dx*dx+dy*dy));//total velocity is constant
        float velX = (float)(5 * dx/d);
        float velY = (float)(5 * dy/d);
        handler.addObject(new Bullet(490,473,velX,velY,ID.Bullet,handler));
        }
    }

