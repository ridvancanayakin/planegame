/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planegame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/**
 *
 * @author RC
 */
public class End extends GameObject{//this oject detects the planes in the end of the screen

    public End(int x, int y, float velX, float velY, ID id) {
        super(x, y, velX, velY, id);
    }

    @Override
    public void tick() {//no need to update
    }

    @Override
    public void render(Graphics g) {
        g.setColor(Color.red);
        g.fillRect(1000,0,10,563);
    }

    @Override
    public Rectangle getBounds() {
        return new Rectangle(1000,0,10,563);
    }
    
}
