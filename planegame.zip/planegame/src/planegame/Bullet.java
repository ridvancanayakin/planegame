/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planegame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;

/**
 *
 * @author RC
 */
public class Bullet extends GameObject {
    private Handler handler;
    public Bullet(int x, int y, float velX, float velY, ID id,Handler handler) {
        super(x, y, velX, velY, id);
        this.handler=handler;
    }

    @Override
    public void tick() {//updates bullet
        x+=velX;
        y+=velY;
    }

    @Override
    public void render(Graphics g) {//renders bullet
        g.setColor(Color.white);
        g.fillOval(x,y,8,8);
    }

    @Override
    public Rectangle getBounds() {//return pos of the bullet
        return new Rectangle(x,y,8,8);
    }
}
