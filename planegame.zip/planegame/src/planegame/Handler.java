
package planegame;

import java.awt.Graphics;
import java.util.LinkedList;

/**
 *
 * @author RC
 */
public class Handler {//this class handles all the objects
    LinkedList<GameObject> object = new LinkedList<GameObject>();
    
    public void tick(){//updates every object
        for(int i=0;i<object.size();i++){
            GameObject tempObject=object.get(i);
            tempObject.tick();
        }
    }
    public void render(Graphics g){//renders every object
        for(int i=0;i<object.size();i++){
            GameObject tempObject=object.get(i);
            tempObject.render(g);
        } 
    
    }
    public void addObject(GameObject tempObject){
        object.add(tempObject);
    }
    public void removeObject(GameObject tempObject){
        object.remove(tempObject);
    }
    
}
