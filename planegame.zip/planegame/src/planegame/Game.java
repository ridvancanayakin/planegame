
package planegame;

import java.awt.Canvas;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.image.BufferStrategy;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 *
 * @author RC
 */
public class Game extends Canvas implements Runnable {
    private boolean isRunning=false;
    private Thread thread;
    private Handler handler;
    public int score=0;
    public int health=3;
    public int enemyn=0;
    
    
    public Game() {
        new Window(1000,563,"Plane Game",this);
        start();
        
        
        handler= new Handler();
        handler.addObject(new End(0,0,3,0,ID.End));
        handler.addObject(new Gun(0,0,0,0,ID.Gun));
        this.addMouseListener(new MouseInput(handler));
        Spawn s=new Spawn(handler,this);
        s.Generate();//a code to spawn enemies
 
    }
    private void start(){
        isRunning=true;
        thread= new Thread(this);
        thread.start();
    }
    private void stop(){
        isRunning=false;
        try {
            thread.join();
        } catch (InterruptedException ex) {
            Logger.getLogger(Game.class.getName()).log(Level.SEVERE, null, ex);
        }
    
    }
    public void run(){//refreshes the screen 
        this.requestFocus();
        long lastTime=System.nanoTime();
        double amountOfTicks=60.0;
        double ns=10000000;
        double delta=0;
        long timer=System.currentTimeMillis();
        int frames=0;
        while(isRunning){
            if(health==0){stop();}
            long now=System.nanoTime();
            delta +=(now-lastTime)/ns;
            lastTime=now;
            while(delta>=1){
                tick();
                delta--;
            }
            render();
            frames++;
            if(System.currentTimeMillis()-timer>1000){
                timer+=1000;
                frames=0;
            }
        }
        stop();
    }
    public void tick(){
        handler.tick();
    }
    public void render(){
        BufferStrategy bs= this.getBufferStrategy();
        if(bs==null){
            this.createBufferStrategy(3);
            return;
        }
        Graphics g= bs.getDrawGraphics();
        /////////////////////////////////
        
        g.setColor(Color.black);
        g.fillRect(0, 0, 1000, 563);
        g.setColor(Color.white);
        g.drawString("Score: "+score,5,20);
        g.drawString("Health: "+health,5,50);
        g.drawString("Enemy: "+enemyn,5,80);
        
        handler.render(g);
        
        /////////////////////////////////
        g.dispose();
        bs.show();
        
    }
    

    public static void main(String[] args) {
        new Game();
        
        
    }

}
