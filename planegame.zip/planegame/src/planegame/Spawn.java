/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package planegame;

import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author RC
 */
public class Spawn {
    private Handler handler;
    private Game game; 
    
    public Spawn(Handler handler,Game game) {
        this.handler=handler;
        this.game=game;
    }
    public void Generate(){
        Random r=new Random();
        while(game.enemyn<11){//spawns new enemies on different heights and
            //speed after random delay.
            int y=r.nextInt(375);
            float velX=2*r.nextFloat()+(float)1.0;
            handler.addObject(new Enemy(0,y,velX,0,ID.Enemy,handler,game));
            game.enemyn++;
            int delay=r.nextInt(1000);
            try {
                TimeUnit.MILLISECONDS.sleep(500+delay);
            } catch (InterruptedException ex) {
                Logger.getLogger(Enemy.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }
}
