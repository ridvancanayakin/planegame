package planegame;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.util.Random;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author RC
 */
public class Enemy extends GameObject{
    private Handler handler;
    private Game game;

    public Enemy(int x,int y,float velX,float velY,ID id,Handler handler,Game game){
        super(x,y,velX,velY,id);
        this.handler=handler;
        this.game=game;
    }
    


    public void tick() {
        x+=velX;
        for(int i=0;i<handler.object.size() ;i++){
            GameObject temp= handler.object.get(i);
            if(temp.getId()==ID.Bullet){//if it collides with bullet
                if(getBounds().intersects(temp.getBounds())){
                    handler.removeObject(temp);
                    handler.removeObject(this);
                    game.score++;
                    game.enemyn--;
                }
            }
            if(temp.getId()==ID.End){//if it passes the screen
                if(getBounds().intersects(temp.getBounds())){
                    handler.removeObject(this);
                    game.health--;
                    game.enemyn--;
                }
            }
            
            
        
        }
    }

    
    public void render(Graphics g) {
        g.setColor(Color.red);
        g.fillRect(x, y, 80, 30);
    }

    
    public Rectangle getBounds() {
        return new Rectangle(x,y,80,30);
    }
    
}
